# Art Nouveau Visual Anchoring MCP Server

An MCP (Model Context Protocol) server that provides AI agents with reference images and style information about Alphonse Mucha's work and Art Nouveau architecture for the "anchoring" technique in visual generation.

## Features

### Tools Provided

1. **get_mucha_references** - Get reference images of Alphonse Mucha's Art Nouveau artwork
2. **get_architecture_references** - Get Art Nouveau architecture reference images
3. **get_style_characteristics** - Get detailed Art Nouveau style information
4. **get_combined_anchors** - Get both artwork and architecture references together
5. **create_prompt_with_anchors** - Generate enhanced prompts with Art Nouveau visual anchors

## Installation

1. Install dependencies:
```bash
pip install -r requirements.txt
```

2. Make the server executable:
```bash
chmod +x art_nouveau_mcp_server.py
```

## Usage

### Running the Server

```bash
python art_nouveau_mcp_server.py
```

The server communicates over stdio and follows the MCP protocol.

### Integration with Claude Desktop

Add to your Claude Desktop config (`~/Library/Application Support/Claude/claude_desktop_config.json` on Mac):

```json
{
  "mcpServers": {
    "art-nouveau-anchoring": {
      "command": "python",
      "args": ["/path/to/art_nouveau_mcp_server.py"]
    }
  }
}
```

### Integration with Other MCP Clients

The server can be used with any MCP-compatible client. Simply run it and connect via stdio.

## Example Tool Calls

### Get Mucha References

```json
{
  "name": "get_mucha_references",
  "arguments": {
    "count": 5
  }
}
```

Returns 5 reference images of Mucha's artwork with URLs and descriptions.

### Get Architecture References

```json
{
  "name": "get_architecture_references",
  "arguments": {
    "count": 5
  }
}
```

Returns 5 Art Nouveau architecture reference images.

### Create Enhanced Prompt

```json
{
  "name": "create_prompt_with_anchors",
  "arguments": {
    "base_prompt": "A woman holding flowers",
    "include_mucha": true,
    "include_architecture": false
  }
}
```

Returns an enhanced prompt with Art Nouveau style characteristics.

## Visual Anchoring Technique

The "anchoring" technique uses reference images to guide AI image generation toward specific styles. This server provides:

- **High-quality reference images** from actual Alphonse Mucha artworks
- **Architectural references** showing Art Nouveau building details
- **Style characteristics** describing visual elements, color palettes, and motifs
- **Enhanced prompts** that incorporate these anchoring elements

## Art Nouveau Style Elements Included

### From Mucha's Work:
- Elegant flowing lines and curves
- Ornate decorative borders
- Feminine figures with floral motifs
- Muted pastel color palettes
- Byzantine influences

### From Architecture:
- Organic, nature-inspired forms
- Asymmetrical compositions
- Decorative ironwork
- Stained glass details
- Integrated art and structure

## Data Sources

The server includes embedded reference data from:
- Google Images search results for Alphonse Mucha artwork
- Art Nouveau architecture photographs
- Style analysis from art history sources

## License

MIT License - Feel free to use and modify

## Contributing

Suggestions and improvements welcome! The reference data can be updated by modifying the REFERENCE_DATA dictionary in the server code.
