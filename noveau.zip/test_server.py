#!/usr/bin/env python3
"""
Test script for Art Nouveau MCP Server
Tests all tools to verify functionality
"""

import asyncio
import json
from mcp import ClientSession
from mcp.client.stdio import stdio_client

async def test_server():
    """Test all MCP server tools."""

    server_params = {
        "command": "python",
        "args": ["art_nouveau_mcp_server.py"]
    }

    async with stdio_client(server_params) as (read, write):
        async with ClientSession(read, write) as session:
            # Initialize
            await session.initialize()

            # List tools
            tools = await session.list_tools()
            print(f"\n=== Available Tools ({len(tools.tools)}) ===")
            for tool in tools.tools:
                print(f"- {tool.name}: {tool.description[:80]}...")

            # Test get_mucha_references
            print("\n=== Testing get_mucha_references ===")
            result = await session.call_tool("get_mucha_references", {"count": 3})
            print(result.content[0].text[:500] + "...")

            # Test get_architecture_references
            print("\n=== Testing get_architecture_references ===")
            result = await session.call_tool("get_architecture_references", {"count": 3})
            print(result.content[0].text[:500] + "...")

            # Test get_style_characteristics
            print("\n=== Testing get_style_characteristics ===")
            result = await session.call_tool("get_style_characteristics", {})
            print(result.content[0].text[:500] + "...")

            # Test create_prompt_with_anchors
            print("\n=== Testing create_prompt_with_anchors ===")
            result = await session.call_tool(
                "create_prompt_with_anchors",
                {
                    "base_prompt": "A woman in a garden",
                    "include_mucha": True,
                    "include_architecture": False
                }
            )
            print(result.content[0].text[:500] + "...")

            print("\n=== All Tests Completed Successfully! ===")

if __name__ == "__main__":
    asyncio.run(test_server())
